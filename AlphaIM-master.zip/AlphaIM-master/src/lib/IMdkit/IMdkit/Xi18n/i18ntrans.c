
#define XIM_t 1
#define TRANS_SERVER 1

//#define X11_t 1

#include <X11/Xtrans/transport.c>
