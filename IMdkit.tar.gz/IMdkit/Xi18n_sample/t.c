#include <stdio.h>
main() {
char *s = "���üy";
while(*s!=0) {
	putchar(*s&0x7f);
	s++;
}
}
